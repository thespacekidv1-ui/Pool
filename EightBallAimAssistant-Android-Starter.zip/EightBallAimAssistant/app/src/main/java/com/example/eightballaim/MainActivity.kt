package com.example.eightballaim

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(20, 28, 38))
        }
        layout.addView(TextView(this).apply { text = "8 Ball Aim Assistant"; textSize = 25f; setTextColor(Color.WHITE) })
        layout.addView(TextView(this).apply {
            text = "\\nManual floating aim guide\\n\\nThis starter draws a direction line over your screen. It does not read the game or calculate automatic shots."
            textSize = 16f; setTextColor(Color.LTGRAY)
        })
        val permission = Button(this).apply { text = "Grant overlay permission" }
        val show = Button(this).apply { text = "Show aiming overlay" }
        val hide = Button(this).apply { text = "Hide overlay" }
        layout.addView(permission); layout.addView(show); layout.addView(hide)
        setContentView(layout)
        permission.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        show.setOnClickListener {
            if (Settings.canDrawOverlays(this)) startService(Intent(this, AimOverlayService::class.java).setAction(AimOverlayService.SHOW)) else permission.performClick()
        }
        hide.setOnClickListener { startService(Intent(this, AimOverlayService::class.java).setAction(AimOverlayService.HIDE)) }
    }
}
