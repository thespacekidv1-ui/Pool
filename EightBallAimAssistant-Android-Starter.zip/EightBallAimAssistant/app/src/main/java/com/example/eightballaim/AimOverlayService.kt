package com.example.eightballaim

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class AimOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) { SHOW -> showPanel(); HIDE -> removePanel() }
        return START_NOT_STICKY
    }

    private fun showPanel() {
        if (panel != null) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 10, 12, 10); setBackgroundColor(0xDD18232D.toInt()) }
        val header = TextView(this).apply { text = "8 Ball Aim • drag here to move"; setTextColor(Color.WHITE); textSize = 14f }
        val guide = AimGuideView(this)
        val slider = SeekBar(this).apply {
            max = 359
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) { guide.angle = value.toFloat(); guide.invalidate() }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        root.addView(header)
        root.addView(guide, LinearLayout.LayoutParams(280, 160))
        root.addView(slider)
        root.addView(TextView(this).apply { text = "Rotate the guide with the slider"; setTextColor(Color.LTGRAY); textSize = 11f })
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 160 }
        header.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; startX=params.x; startY=params.y; return true }
                    MotionEvent.ACTION_MOVE -> { params.x=startX+(e.rawX-downX).toInt(); params.y=startY+(e.rawY-downY).toInt(); wm.updateViewLayout(root, params); return true }
                }
                return true
            }
        })
        panel = root
        wm.addView(root, params)
    }

    private fun removePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        stopSelf()
    }
    override fun onDestroy() { removePanel(); super.onDestroy() }
    companion object { const val SHOW = "com.example.eightballaim.SHOW"; const val HIDE = "com.example.eightballaim.HIDE" }
}
