package com.example.eightballaim

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PathEffect
import android.graphics.DashPathEffect
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

class AimGuideView(context: Context) : View(context) {
    var angle = 0f
    private val solid = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.CYAN; strokeWidth = 5f; style = Paint.Style.STROKE }
    private val dashed = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.YELLOW; strokeWidth = 3f; style = Paint.Style.STROKE; pathEffect = DashPathEffect(floatArrayOf(12f, 9f), 0f) }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f; val cy = height / 2f
        val rad = Math.toRadians(angle.toDouble())
        val dx = cos(rad).toFloat(); val dy = -sin(rad).toFloat()
        canvas.drawCircle(cx, cy, 8f, dot)
        canvas.drawLine(cx, cy, cx + dx * width * .46f, cy + dy * height * .46f, solid)
        canvas.drawLine(cx - dx * width * .30f, cy - dy * height * .30f, cx, cy, dashed)
    }
}
