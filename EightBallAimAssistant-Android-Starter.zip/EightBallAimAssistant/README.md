# 8 Ball Aim Assistant — Android starter

A basic Android Studio project with a movable floating panel and a manually rotatable direction guide.

## Build an APK
1. Install Android Studio.
2. Open this project folder in Android Studio.
3. Allow Gradle to sync and install Android SDK Platform 35 if prompted.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.

## Use
1. Install the APK on your Android phone.
2. Open **8 Ball Aim Assistant**.
3. Tap **Grant overlay permission** and allow display over other apps.
4. Return and tap **Show aiming overlay**.
5. Use the slider to rotate the line; drag the panel by its header.
6. Tap **Hide overlay** in the main app to close it.

## Current limitations
This first version is a manual visual guide only. It does not inspect the 8 Ball Pool screen, detect balls or pockets, predict collisions, or automate gameplay. It is not affiliated with Miniclip. Only grant overlay permission to apps you trust.
